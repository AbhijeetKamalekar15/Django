from django.shortcuts import render
from django.http import HttpResponse

# def index(request):
#     return HttpResponse("ONLINE DINOSAUR MESEUM")

def aboutus(request):
    return HttpResponse(request,'aboutus.html')

def login(request):
    return render(request,'login.html')

def contactus(request):
    return render(request,'contactus.html')

